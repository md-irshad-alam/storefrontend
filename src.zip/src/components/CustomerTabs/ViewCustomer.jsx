import React, { useState, useEffect } from 'react';
import { Container, Form, Card, Row, Col } from 'react-bootstrap';

const ViewCustomer = () => {
  return (
    <Container>
      <Card.Title>View Customer</Card.Title>
      <Card>
        <Row>
          <Col></Col>
        </Row>
        <br />
      </Card>
    </Container>
  );
};

export default ViewCustomer;
